
public_key_str = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp5p+00HlcBpbsQjs1yCH
bAGjc7KVvL/bzIqKO3NKcGf8lJstt/c52k0p1e3LCIZE3IybufbMzbyH1cqgr4lw
qgzmCRrGOCsFpyCaAgIFFdJV72xl5KgYgl5RgrCVha1DctwGCPcBwua1ZqXVZpJM
8kiz4dhdR9WrEqFzh9kAedLN+ZOe84eMX7qiBT6zuYvgQUVksqi2CoLUX2t3A0vR
vJY0A0uU4h3mT1ljL0mkenS+ZH0oDfvYK6qiumxtR7ZZOaK/I32DcQcRZ//HzJQz
hjT4AvylCA0Xc5JPjLV0jW8OFqwhj4C97eCVxSKzmgq9OHbnlscggrUHJFxQ9L5t
KwIDAQAB
-----END PUBLIC KEY-----"""

private_key_str = """-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFJDBWBgkqhkiG9w0BBQ0wSTAxBgkqhkiG9w0BBQwwJAQQWu0A8Ld/TtOo9xAN
xZEPxAICCAAwDAYIKoZIhvcNAgkFADAUBggqhkiG9w0DBwQINNZlsIWFNHUEggTI
tgML8RKJrFJCu5APnamyG47L4X1ZQN5WOhQO46Wm3vvVKWBOd72I62aK1W4ktSki
IhvwojFgYqaf6HJ2ITDiDg0XNfP220aQ0Sil+z0w8t5w6ZQPSJHyTUkdbENvs1Eh
rpnOFaaDpSA39AvF6rcPChqDu+9oHHoqwca6V6fYnh5aTiovryRtuxqigKrh7BeU
9qG5maCYyO7Y9y3P48FcNgtgc2y90cV4Isf0apc6XQHSLJezuTiCKoncqcVRZEeU
GbeMdDQZOv2n+WWCxxuLM5P/0nOl9igr/7Ztfn/dBOpUAThXfqsPsWj4Myo9/Nzc
7Yxey7hzLXUwl30N4CqlnACizKV9H4H/v7nXPWJTmfYm4KPMFm/yU5XR2zRPg0LH
Cilf3E7e6qXsFMPH2xMO5mQlPDeYQBf1D7/rdeZufsIxnAPH7TA5wek8dLzmddFh
7SOJYyhkoqfW3keVLYJ5gIzPAucJH/5/DaPB8LWYOZvgJcJk8n/WTGlYUpFIbzBy
N1QINIlCENLbPQsaOLqYKoblJtumumUH+9JVoSEbiTgy2ADFxQ6E63A3Fp6PT1Uy
/QA99pxryv6xdK5j8YVyzUEIZcm6fTQhcJNcv1SckJOXTmn8KAxkh/b/tfpH+pOG
00c+yBOaiSxDcVANQRgzK9kYB969VlUTKYRnMecH5A9T42zbGwK8VpzVaO9LzyU3
Erg2OgDRh84T5QucUBI260U1V4Z+a9B75/oPIFm2ovPN9/Wq9gc9gVinUFVuZR5d
nJofsQaRK+Hc5NwOHKSL3UDIjOEKvW7ExFR+BTwoETtjXVaXOj12+jyzGQJF4MYK
WW5hEOuFzezw6ujGbzTLnIGowJ2znwEvNXKq/SB5/deoB9v+Mucww3+OlCZGSZvH
bsimayPPqHouvUM72+6/A4UGA7ZUVqKBZFD5n4+iMo7j8tHlpZR8eEz+SG7Gkfkw
KsvogDYVx8H10O6jzJU658BNaoaXDFeO2CH8YhfWVpFvJJBNS5aBNBjjQjv/AfkF
h62LWdxiBNV49CnBlzE35kBLjoiDSiTb4pG4QX+ba9im3EivXQ7FzruLQWMrXLBv
nT7dYqmJ3nsOjbS2IzFPq2JdQjEXBDJb7pmgCyldtXFyrQlb71urF6lLo9GHw+j8
6R9MaVCdSPid98mJ8fHScq8NHKKSB6MZTelzs+B7f42gfZW+Syb8TQ+mcZIvZKuM
OcfeHVdem91sdtYQOqxIjCUBPQ0MX6LxWoqH6evA8mafkMuXp9uSFOAZ3/35kcg1
NG1kslcUHqSBxAUGCj+Hh1pm1mxtJ+EwXv6sxizyGEMjfDkUDovaG6xQ6y5bHiMF
w+r6fJF8ozayKlQGUQqSJfDdBqpqIpzzLgrvrjFOQrUarETAhS+HwULsH5R7/ILK
X1pdHIU0D5rMblaSvyKTRX7qoY1cs8orUpS/cjL43n6ahrsK//3FhnAyYXccgNUz
HMqqX+AihE4tf0MPgaOyEcYRlXn/8OZpwjxVyU1tjYNysnawo+MnuByeB0lWBQQR
WlN+wqOMddC6RbEp3H+VP9FLv4kWmXLCKnwaYxc4mlqg9DKK0g1LchcvvCE+3NS9
kIC8EP6s/mopGE7ZAOaPRPNTOLG2sUpv
-----END ENCRYPTED PRIVATE KEY-----"""

public_key_str_from_js = """-----BEGIN PUBLIC KEY-----
MIIBITANBgkqhkiG9w0BAQEFAAOCAQ4AMIIBCQKCAQB/xDswXqnRKPAyHXb2GWUA
TLtpBsBbSMrZ3feoJujbUBOIzTz0C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCP
dl1opBWvjnw1+DEIyeCf1StyIXBK4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepF
OSLtzNhSNiCTz0qn1GgoS0Dt0XCp+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCk
WUoBoFucUDdIYXX5+NbCdIRWlzteBUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgq
HQiJsEIY3CQT3dsX5KwrUdJ3TaziHbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9
AgMBAAE=
-----END PUBLIC KEY-----"""

private_key_str_from_js = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQB/xDswXqnRKPAyHXb2GWUATLtpBsBbSMrZ3feoJujbUBOIzTz0
C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCPdl1opBWvjnw1+DEIyeCf1StyIXBK
4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepFOSLtzNhSNiCTz0qn1GgoS0Dt0XCp
+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCkWUoBoFucUDdIYXX5+NbCdIRWlzte
BUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgqHQiJsEIY3CQT3dsX5KwrUdJ3Tazi
HbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9AgMBAAECggEAQF0jkCdwFv0vm596
SVnbpr4A/1S2XIYcIosOcvg/ABSj8pup5CtXtTE3T4uT0U+3jJvev1naaKhjRMyv
4gah9bOkNM3MWudFrY59bTb94KbrvxAXWLH6s8+NhVIQmnuI7nZk2CnO81HNyF8k
VLRyEzNIZFF4fFnmKXAY5Nk9K2ab/EGs2FE2Z5nE3ylbAKnTzDDZR7fGnVsTTkaI
i6W9nha5Swl6t0vfbcM3bOMKgrct7oMvCkngnkCsoIK12D0h2Ipuco18MPubKn6F
Mx8JFO3PWlY6fyZKUCFJC1lWbMVUQEVUOqOXrSbl5FZHgkqIWQC+ABSaUEpThxgR
zig8oQKBgQDbwP5DjgIUuydCrQsqtnJieME0FSzZmT+7yU4QjUGkBT/PIoGyPnbQ
uAhyo84UL8+850DctmTHChGhPvgafuxdFHBylBp8R4P4lq8MQGoNlrGYw04Ca4u4
LPhZJUsty969toIhVNJkCP2m0tLw4adqhj2DWTwyCBudG99qC2ZkxQKBgQCU1x0/
95YtysS8gC50i5GCtzxpEWit8DcTkgV3uSMskKyiJc62I6aHR/Fw0q+Li1GIxt09
Sw9M5EQv2R7Lmf8aOVvvlwWAdgNoJCSaObOxoOGtC9sG8gg+QiJAYdoMQXF5zpfC
e1xGOzUuR4sBGWbA6df4vcPZcofbKl8l1OcDmQKBgQCm4bv1v10TM0FQYCsPx7e7
0ioejEogAUImMGyJI0yK67WWboUBwG/odylrLbwtFlXzBcb7FcQYZywWQMSXEnYb
BY+TY6dtY73zxTKv4ibnpN2/vel66wMS3YvH3wtlfuHrPjM6brjLYQyHaKjqZuMF
gWYrXlPZRtD5kZYraPbcZQKBgB3EY+ouJw/jdLNKY4AVhbWB1gghXjEjULCOTJ+k
HD/Gc3A+ZXgR6zU1EzmAOXGMHHNhak/e2iGDqYt0Pe90Tgu9mwBw0L3fXFEQoW1i
yuhkh53nOBfMgg+JhHYh280FrZ8xzTItH8hAASPPVSKUJPPCENqDgU7U1AzmDX9w
c/9JAoGBANTO5nuw1ckZnhtho0QSS8safHzfy/zEXguSAr7bCFY/1lYEJR8mfX2w
yks2AyhKDNjyjmcLWiXfaRsMFkW9gUML9+mvQ+lGEAgryY4DVHZcfMq7dE4RaB4q
cLVtcuwhEOOF8ObOpOGB9gkmbqh/qIOgy4c2Jm7mpNgAPicTXfk3
-----END RSA PRIVATE KEY-----"""

import base64
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend

def load_public_key(public_key_str):
    return serialization.load_pem_public_key(
        public_key_str.encode(),
        backend=default_backend()
    )

def load_private_key(private_key_str, password=None):
    methods = [
        # Method 1: Try loading as unencrypted
        lambda: serialization.load_pem_private_key(
            private_key_str.encode(),
            password=None,
            backend=default_backend()
        ),
        # Method 2: Try loading with empty password
        lambda: serialization.load_pem_private_key(
            private_key_str.encode(),
            password=b'',
            backend=default_backend()
        ),
        # Method 3: Try loading with provided password
        lambda: serialization.load_pem_private_key(
            private_key_str.encode(),
            password=password.encode() if password else None,
            backend=default_backend()
        ),
        # Method 4: Try loading as PKCS#1 format
        lambda: serialization.load_der_private_key(
            serialization.load_pem_private_key(
                private_key_str.encode(),
                password=None,
                unsafe_skip_rsa_key_validation=True,
                backend=default_backend()
            ).private_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ),
            password=None,
            backend=default_backend()
        )
    ]

    for method in methods:
        try:
            return method()
        except Exception:
            continue

    raise ValueError("Unable to load the private key. The format might be unsupported or the password might be incorrect.")

def encrypt_message(message, public_key):
    encrypted = public_key.encrypt(
        message.encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return base64.b64encode(encrypted).decode()

def decrypt_message(encrypted_message, private_key):
    decrypted = private_key.decrypt(
        base64.b64decode(encrypted_message),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted.decode('utf-8')

# Example usage
if __name__ == "__main__":

    # Password for the private key (set to None if unencrypted)
    private_key_password = ""  # or None if unencrypted

    # try:
    #     # Load the keys
    #     public_key = load_public_key(public_key_str)
    #     private_key = load_private_key(private_key_str, private_key_password)

    #     # Original message
    #     message = "123456"
    #     print(f"Original message: {message}")

    #     # Encrypt the message
    #     encrypted = encrypt_message(message, public_key)
    #     encrypted= "M6Ds78DlGHZYILhDGbSJRn02Y3e0n3E1sdY4tTVxvgKDyoyQ1KXMkZcEAB576j+kQqFkfnzobhVkHUFsu9mt96Pw1MvIHhCqehJoexX5s7uRajn8xf8CSnSCoCwhtYAniO8KGUmbq6+daRlLnlueSiI6IQFAfC7hkRXfJHjDdOVpuEqrGKhf7gjvksb5ynHWGhe06V4humaX14+N/wKd46xpJeLcNEr/hp77N0g2CDdniRmsTCdUD34RxHXhAT8K0faOpfhuHIAoI3j+KHhw3V02lBiG3Q+GlsjguW/FNq2uUfnAMEKj37qxAFCaquIRTBOEe6VTLLCkAYnV68pHFg=="
        
    #     print(f"Encrypted message (base64): {encrypted}")

    #     # Decrypt the message
    #     decrypted = decrypt_message(encrypted, private_key)
    #     print(f"Decrypted message: {decrypted}")
    # except ValueError as e:
    #     print(f"Key loading error: {str(e)}")
    # except Exception as e:
    #     print(f"An error occurred: {str(e)}")
    
    try:
        # Load the keys
        public_key = load_public_key(public_key_str2)
        private_key = load_private_key(private_key_str2, private_key_password)

        # Original message
        message = "你好，Brother!"
        print(f"Original message: {message}")

        # Encrypt the message
        encrypted = encrypt_message(message, public_key)
        print(f"Encrypted message (base64): {encrypted}")
        encrypted = "Zf5ShYN0HDNfnb0I5k6WJ7SNlv8rtd0eULHkGe16ODi2ZnggCAFRgnY5zEEIrgAj85TvBkjexkR3KgM6jiHwyvMqew2wr1Mx07EjONRjQz8zzwlMZjupPzCiacfjy/mT8J/Hp/+TTs1P5mrcMjP1oPNQMiDtZOXgUzCUvW3HVoI70ZFRNeViTvqzwM7FJnK1VabESfDRC3YkezihsIV+D6Az44sDPBXYKlx7MzeV6n7R69BzbQZMjN4bQCIiydXeaywpkMSNPT2qPWdiICJvzDBYDslR/vZmBLMrrJwuKos3hO3GqJJRRlo3CGsCVg3MVdJpv0NoUqo5oROjS8Q8GQ=="
        
        

        # Decrypt the message
        decrypted = decrypt_message(encrypted, private_key)
        print(f"Decrypted message: {decrypted}")
    except ValueError as e:
        print(f"Key loading error: {str(e)}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")