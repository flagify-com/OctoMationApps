import base64
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend

def load_public_key(public_key_str):
    try:
        return serialization.load_pem_public_key(
            public_key_str.encode(),
            backend=default_backend()
        )
    except Exception as e:
        print(f"Error loading public key: {str(e)}")
        raise

def load_private_key(private_key_str, password=None):
    try:
        return serialization.load_pem_private_key(
            private_key_str.encode(),
            password=password.encode() if password else None,
            backend=default_backend()
        )
    except Exception as e:
        print(f"Error loading private key: {str(e)}")
        # If loading as PEM fails, try loading as DER
        try:
            return serialization.load_der_private_key(
                base64.b64decode(private_key_str),
                password=password.encode() if password else None,
                backend=default_backend()
            )
        except Exception as e:
            print(f"Error loading private key as DER: {str(e)}")
            raise ValueError("Unable to load the private key. The format might be unsupported or incorrect.")

def decrypt_message(encrypted_message, private_key):
    encrypted_bytes = base64.b64decode(encrypted_message)
    
    # Try different decryption methods
    decryption_methods = [
        # OAEP with SHA-256
        lambda: private_key.decrypt(
            encrypted_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        ),
        # OAEP with SHA-1
        lambda: private_key.decrypt(
            encrypted_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA1()),
                algorithm=hashes.SHA1(),
                label=None
            )
        ),
        # PKCS1v15 padding
        lambda: private_key.decrypt(
            encrypted_bytes,
            padding.PKCS1v15()
        )
    ]
    
    for method in decryption_methods:
        try:
            decrypted = method()
            # Try different encodings
            for encoding in ['utf-8', 'ascii', 'latin-1']:
                try:
                    return decrypted.decode(encoding)
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            print(f"Decryption method failed: {str(e)}")
            continue
    
    raise ValueError("Unable to decrypt the message. The encryption method might be incompatible.")

# Example usage
if __name__ == "__main__":
    public_key_str = """-----BEGIN PUBLIC KEY-----
MIIBITANBgkqhkiG9w0BAQEFAAOCAQ4AMIIBCQKCAQB/xDswXqnRKPAyHXb2GWUA
TLtpBsBbSMrZ3feoJujbUBOIzTz0C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCP
dl1opBWvjnw1+DEIyeCf1StyIXBK4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepF
OSLtzNhSNiCTz0qn1GgoS0Dt0XCp+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCk
WUoBoFucUDdIYXX5+NbCdIRWlzteBUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgq
HQiJsEIY3CQT3dsX5KwrUdJ3TaziHbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9
AgMBAAE=
-----END PUBLIC KEY-----"""

    private_key_str = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQB/xDswXqnRKPAyHXb2GWUATLtpBsBbSMrZ3feoJujbUBOIzTz0
C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCPdl1opBWvjnw1+DEIyeCf1StyIXBK
4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepFOSLtzNhSNiCTz0qn1GgoS0Dt0XCp
+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCkWUoBoFucUDdIYXX5+NbCdIRWlzte
BUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgqHQiJsEIY3CQT3dsX5KwrUdJ3Tazi
HbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9AgMBAAECggEAQF0jkCdwFv0vm596
SVnbpr4A/1S2XIYcIosOcvg/ABSj8pup5CtXtTE3T4uT0U+3jJvev1naaKhjRMyv
4gah9bOkNM3MWudFrY59bTb94KbrvxAXWLH6s8+NhVIQmnuI7nZk2CnO81HNyF8k
VLRyEzNIZFF4fFnmKXAY5Nk9K2ab/EGs2FE2Z5nE3ylbAKnTzDDZR7fGnVsTTkaI
i6W9nha5Swl6t0vfbcM3bOMKgrct7oMvCkngnkCsoIK12D0h2Ipuco18MPubKn6F
Mx8JFO3PWlY6fyZKUCFJC1lWbMVUQEVUOqOXrSbl5FZHgkqIWQC+ABSaUEpThxgR
zig8oQKBgQDbwP5DjgIUuydCrQsqtnJieME0FSzZmT+7yU4QjUGkBT/PIoGyPnbQ
uAhyo84UL8+850DctmTHChGhPvgafuxdFHBylBp8R4P4lq8MQGoNlrGYw04Ca4u4
LPhZJUsty969toIhVNJkCP2m0tLw4adqhj2DWTwyCBudG99qC2ZkxQKBgQCU1x0/
95YtysS8gC50i5GCtzxpEWit8DcTkgV3uSMskKyiJc62I6aHR/Fw0q+Li1GIxt09
Sw9M5EQv2R7Lmf8aOVvvlwWAdgNoJCSaObOxoOGtC9sG8gg+QiJAYdoMQXF5zpfC
e1xGOzUuR4sBGWbA6df4vcPZcofbKl8l1OcDmQKBgQCm4bv1v10TM0FQYCsPx7e7
0ioejEogAUImMGyJI0yK67WWboUBwG/odylrLbwtFlXzBcb7FcQYZywWQMSXEnYb
BY+TY6dtY73zxTKv4ibnpN2/vel66wMS3YvH3wtlfuHrPjM6brjLYQyHaKjqZuMF
gWYrXlPZRtD5kZYraPbcZQKBgB3EY+ouJw/jdLNKY4AVhbWB1gghXjEjULCOTJ+k
HD/Gc3A+ZXgR6zU1EzmAOXGMHHNhak/e2iGDqYt0Pe90Tgu9mwBw0L3fXFEQoW1i
yuhkh53nOBfMgg+JhHYh280FrZ8xzTItH8hAASPPVSKUJPPCENqDgU7U1AzmDX9w
c/9JAoGBANTO5nuw1ckZnhtho0QSS8safHzfy/zEXguSAr7bCFY/1lYEJR8mfX2w
yks2AyhKDNjyjmcLWiXfaRsMFkW9gUML9+mvQ+lGEAgryY4DVHZcfMq7dE4RaB4q
cLVtcuwhEOOF8ObOpOGB9gkmbqh/qIOgy4c2Jm7mpNgAPicTXfk3
-----END RSA PRIVATE KEY-----"""

    try:
        # Load the keys
        public_key = load_public_key(public_key_str)
        private_key = load_private_key(private_key_str)

        # Original message
        message = "你好，Brother!"
        print(f"Original message: {message}")

        # Encrypt the message
        encrypted = encrypt_message(message, public_key)
        print(f"Encrypted message (base64): {encrypted}")
        # Encrypted message from JavaScript
        encrypted = "SyPlDLOYqARqWYy2orqTKcTWR7dtFS3QCqiLfPuz2QQftMGoeTrvxOroY8P9yfYk/KSSrUJA6bFiQ6W831sONn7Y3ufdCXkOG782QiZC5zsnA5RNgeczWh9AyRsrRkFp4zsjfCCjNRvCXlW5kG0lW6+H2lvL9LvvTmfYSNcfTw+y+18+RAR/f4GEbKGuXv38CJ+L8hotIirhRnOuy+pQc+QC4jfhUVCLxF1N9CeioiuAn3m9edafqjS7j2ujCmsN0JKYBq2OwAk4VERpPPJWcfrjh6r8ddLhWXYhSiHyMko0i2lH7vojMpINy9Y/TyIYVQQcOMuP6fmXyPqLAiSuoQ=="
        
        # Decrypt the message
        decrypted = decrypt_message(encrypted, private_key)
        print(f"Decrypted message: {decrypted}")
    except ValueError as e:
        print(f"Key loading or decryption error: {str(e)}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")