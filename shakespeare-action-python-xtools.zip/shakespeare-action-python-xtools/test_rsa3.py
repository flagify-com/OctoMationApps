import base64
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend

def load_public_key(public_key_str, encoding='utf-8'):
    try:
        # First, try to load as PEM
        return serialization.load_pem_public_key(
            public_key_str.encode(encoding),
            backend=default_backend()
        )
    except ValueError:
        # If PEM fails, try to load as DER
        try:
            return serialization.load_der_public_key(
                public_key_str,
                backend=default_backend()
            )
        except ValueError:
            # If both PEM and DER fail, try to load as SSH public key
            try:
                return serialization.load_ssh_public_key(
                    public_key_str.encode(encoding),
                    backend=default_backend()
                )
            except Exception as e:
                # print(f"Error loading public key: {str(e)}")
                raise ValueError("Unsupported key format. Tried PEM, DER, and SSH formats.")


def load_private_key(private_key_str, password=None, encoding='utf-8'):
    if password is not None:
        password = password.encode(encoding)

    def try_load(loader, key_bytes):
        try:
            return loader(
                key_bytes,
                password=password,
                backend=default_backend()
            )
        except (ValueError, TypeError):
            return None

    # Convert string to bytes if it's not already
    key_bytes = private_key_str.encode(encoding) if isinstance(private_key_str, str) else private_key_str

    # Try loading as PEM
    key = try_load(serialization.load_pem_private_key, key_bytes)
    if key:
        return key

    # Try loading as DER
    key = try_load(serialization.load_der_private_key, key_bytes)
    if key:
        return key

    # If both PEM and DER fail, try to load as PKCS#8
    try:
        key = serialization.load_pkcs8_private_key(
            key_bytes,
            password=password,
            backend=default_backend()
        )
        return key
    except ValueError:
        pass

    # If all attempts fail, raise an error
    raise ValueError("Unsupported key format. Tried PEM, DER, and PKCS#8 formats.")

def encrypt_message(message, public_key, padding_method='OAEP_SHA256'):
    try:
        if padding_method == 'OAEP_SHA256':
            padder = padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        elif padding_method == 'OAEP_SHA1':
            padder = padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA1()),
                algorithm=hashes.SHA1(),
                label=None
            )
        elif padding_method == 'PKCS1v15':
            padder = padding.PKCS1v15()
        else:
            raise ValueError(f"Unsupported padding method: {padding_method}")

        encrypted = public_key.encrypt(
            message.encode('utf-8'),
            padder
        )
        return base64.b64encode(encrypted).decode('utf-8')
    except Exception as e:
        # print(f"Encryption error: {str(e)}")
        raise

def decrypt_message(encrypted_message, private_key):
    encrypted_bytes = base64.b64decode(encrypted_message)
    
    decryption_methods = [
        ('OAEP_SHA256', lambda: private_key.decrypt(
            encrypted_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )),
        ('OAEP_SHA1', lambda: private_key.decrypt(
            encrypted_bytes,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA1()),
                algorithm=hashes.SHA1(),
                label=None
            )
        )),
        ('PKCS1v15', lambda: private_key.decrypt(
            encrypted_bytes,
            padding.PKCS1v15()
        ))
    ]
    
    for method_name, method in decryption_methods:
        try:
            decrypted = method()
            return decrypted.decode('utf-8'), method_name
        except Exception as e:
            # print(f"Decryption method {method_name} failed: {str(e)}")
            continue
    
    raise ValueError("Unable to decrypt the message. The encryption method might be incompatible.")

# Example usage
if __name__ == "__main__":
    public_key_str_from_js = """-----BEGIN PUBLIC KEY-----
MIIBITANBgkqhkiG9w0BAQEFAAOCAQ4AMIIBCQKCAQB/xDswXqnRKPAyHXb2GWUA
TLtpBsBbSMrZ3feoJujbUBOIzTz0C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCP
dl1opBWvjnw1+DEIyeCf1StyIXBK4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepF
OSLtzNhSNiCTz0qn1GgoS0Dt0XCp+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCk
WUoBoFucUDdIYXX5+NbCdIRWlzteBUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgq
HQiJsEIY3CQT3dsX5KwrUdJ3TaziHbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9
AgMBAAE=
-----END PUBLIC KEY-----"""

    private_key_str_from_js = """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQB/xDswXqnRKPAyHXb2GWUATLtpBsBbSMrZ3feoJujbUBOIzTz0
C4l9wS46UT30Oco0dZvD3T6WP6kCPZaE+HCPdl1opBWvjnw1+DEIyeCf1StyIXBK
4iZlfKwVrVdah5UyF/xUMtQk4lVzdQ2HlepFOSLtzNhSNiCTz0qn1GgoS0Dt0XCp
+C7de2FvejrpsAAASPaw7qwvAryqGTR4eMCkWUoBoFucUDdIYXX5+NbCdIRWlzte
BUmJJ6XxuZrWDHXOCXpAnmBWRjjCKN9piDgqHQiJsEIY3CQT3dsX5KwrUdJ3Tazi
HbOhnbbxCgmWpAWMRUXhQPb99VfrhNQVI4i9AgMBAAECggEAQF0jkCdwFv0vm596
SVnbpr4A/1S2XIYcIosOcvg/ABSj8pup5CtXtTE3T4uT0U+3jJvev1naaKhjRMyv
4gah9bOkNM3MWudFrY59bTb94KbrvxAXWLH6s8+NhVIQmnuI7nZk2CnO81HNyF8k
VLRyEzNIZFF4fFnmKXAY5Nk9K2ab/EGs2FE2Z5nE3ylbAKnTzDDZR7fGnVsTTkaI
i6W9nha5Swl6t0vfbcM3bOMKgrct7oMvCkngnkCsoIK12D0h2Ipuco18MPubKn6F
Mx8JFO3PWlY6fyZKUCFJC1lWbMVUQEVUOqOXrSbl5FZHgkqIWQC+ABSaUEpThxgR
zig8oQKBgQDbwP5DjgIUuydCrQsqtnJieME0FSzZmT+7yU4QjUGkBT/PIoGyPnbQ
uAhyo84UL8+850DctmTHChGhPvgafuxdFHBylBp8R4P4lq8MQGoNlrGYw04Ca4u4
LPhZJUsty969toIhVNJkCP2m0tLw4adqhj2DWTwyCBudG99qC2ZkxQKBgQCU1x0/
95YtysS8gC50i5GCtzxpEWit8DcTkgV3uSMskKyiJc62I6aHR/Fw0q+Li1GIxt09
Sw9M5EQv2R7Lmf8aOVvvlwWAdgNoJCSaObOxoOGtC9sG8gg+QiJAYdoMQXF5zpfC
e1xGOzUuR4sBGWbA6df4vcPZcofbKl8l1OcDmQKBgQCm4bv1v10TM0FQYCsPx7e7
0ioejEogAUImMGyJI0yK67WWboUBwG/odylrLbwtFlXzBcb7FcQYZywWQMSXEnYb
BY+TY6dtY73zxTKv4ibnpN2/vel66wMS3YvH3wtlfuHrPjM6brjLYQyHaKjqZuMF
gWYrXlPZRtD5kZYraPbcZQKBgB3EY+ouJw/jdLNKY4AVhbWB1gghXjEjULCOTJ+k
HD/Gc3A+ZXgR6zU1EzmAOXGMHHNhak/e2iGDqYt0Pe90Tgu9mwBw0L3fXFEQoW1i
yuhkh53nOBfMgg+JhHYh280FrZ8xzTItH8hAASPPVSKUJPPCENqDgU7U1AzmDX9w
c/9JAoGBANTO5nuw1ckZnhtho0QSS8safHzfy/zEXguSAr7bCFY/1lYEJR8mfX2w
yks2AyhKDNjyjmcLWiXfaRsMFkW9gUML9+mvQ+lGEAgryY4DVHZcfMq7dE4RaB4q
cLVtcuwhEOOF8ObOpOGB9gkmbqh/qIOgy4c2Jm7mpNgAPicTXfk3
-----END RSA PRIVATE KEY-----"""

    public_key_str_from_openssl = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp5p+00HlcBpbsQjs1yCH
bAGjc7KVvL/bzIqKO3NKcGf8lJstt/c52k0p1e3LCIZE3IybufbMzbyH1cqgr4lw
qgzmCRrGOCsFpyCaAgIFFdJV72xl5KgYgl5RgrCVha1DctwGCPcBwua1ZqXVZpJM
8kiz4dhdR9WrEqFzh9kAedLN+ZOe84eMX7qiBT6zuYvgQUVksqi2CoLUX2t3A0vR
vJY0A0uU4h3mT1ljL0mkenS+ZH0oDfvYK6qiumxtR7ZZOaK/I32DcQcRZ//HzJQz
hjT4AvylCA0Xc5JPjLV0jW8OFqwhj4C97eCVxSKzmgq9OHbnlscggrUHJFxQ9L5t
KwIDAQAB
-----END PUBLIC KEY-----"""

    private_key_str_from_openssl = """-----BEGIN ENCRYPTED PRIVATE KEY-----
MIIFJDBWBgkqhkiG9w0BBQ0wSTAxBgkqhkiG9w0BBQwwJAQQWu0A8Ld/TtOo9xAN
xZEPxAICCAAwDAYIKoZIhvcNAgkFADAUBggqhkiG9w0DBwQINNZlsIWFNHUEggTI
tgML8RKJrFJCu5APnamyG47L4X1ZQN5WOhQO46Wm3vvVKWBOd72I62aK1W4ktSki
IhvwojFgYqaf6HJ2ITDiDg0XNfP220aQ0Sil+z0w8t5w6ZQPSJHyTUkdbENvs1Eh
rpnOFaaDpSA39AvF6rcPChqDu+9oHHoqwca6V6fYnh5aTiovryRtuxqigKrh7BeU
9qG5maCYyO7Y9y3P48FcNgtgc2y90cV4Isf0apc6XQHSLJezuTiCKoncqcVRZEeU
GbeMdDQZOv2n+WWCxxuLM5P/0nOl9igr/7Ztfn/dBOpUAThXfqsPsWj4Myo9/Nzc
7Yxey7hzLXUwl30N4CqlnACizKV9H4H/v7nXPWJTmfYm4KPMFm/yU5XR2zRPg0LH
Cilf3E7e6qXsFMPH2xMO5mQlPDeYQBf1D7/rdeZufsIxnAPH7TA5wek8dLzmddFh
7SOJYyhkoqfW3keVLYJ5gIzPAucJH/5/DaPB8LWYOZvgJcJk8n/WTGlYUpFIbzBy
N1QINIlCENLbPQsaOLqYKoblJtumumUH+9JVoSEbiTgy2ADFxQ6E63A3Fp6PT1Uy
/QA99pxryv6xdK5j8YVyzUEIZcm6fTQhcJNcv1SckJOXTmn8KAxkh/b/tfpH+pOG
00c+yBOaiSxDcVANQRgzK9kYB969VlUTKYRnMecH5A9T42zbGwK8VpzVaO9LzyU3
Erg2OgDRh84T5QucUBI260U1V4Z+a9B75/oPIFm2ovPN9/Wq9gc9gVinUFVuZR5d
nJofsQaRK+Hc5NwOHKSL3UDIjOEKvW7ExFR+BTwoETtjXVaXOj12+jyzGQJF4MYK
WW5hEOuFzezw6ujGbzTLnIGowJ2znwEvNXKq/SB5/deoB9v+Mucww3+OlCZGSZvH
bsimayPPqHouvUM72+6/A4UGA7ZUVqKBZFD5n4+iMo7j8tHlpZR8eEz+SG7Gkfkw
KsvogDYVx8H10O6jzJU658BNaoaXDFeO2CH8YhfWVpFvJJBNS5aBNBjjQjv/AfkF
h62LWdxiBNV49CnBlzE35kBLjoiDSiTb4pG4QX+ba9im3EivXQ7FzruLQWMrXLBv
nT7dYqmJ3nsOjbS2IzFPq2JdQjEXBDJb7pmgCyldtXFyrQlb71urF6lLo9GHw+j8
6R9MaVCdSPid98mJ8fHScq8NHKKSB6MZTelzs+B7f42gfZW+Syb8TQ+mcZIvZKuM
OcfeHVdem91sdtYQOqxIjCUBPQ0MX6LxWoqH6evA8mafkMuXp9uSFOAZ3/35kcg1
NG1kslcUHqSBxAUGCj+Hh1pm1mxtJ+EwXv6sxizyGEMjfDkUDovaG6xQ6y5bHiMF
w+r6fJF8ozayKlQGUQqSJfDdBqpqIpzzLgrvrjFOQrUarETAhS+HwULsH5R7/ILK
X1pdHIU0D5rMblaSvyKTRX7qoY1cs8orUpS/cjL43n6ahrsK//3FhnAyYXccgNUz
HMqqX+AihE4tf0MPgaOyEcYRlXn/8OZpwjxVyU1tjYNysnawo+MnuByeB0lWBQQR
WlN+wqOMddC6RbEp3H+VP9FLv4kWmXLCKnwaYxc4mlqg9DKK0g1LchcvvCE+3NS9
kIC8EP6s/mopGE7ZAOaPRPNTOLG2sUpv
-----END ENCRYPTED PRIVATE KEY-----"""

    try:
        public_key = load_public_key(public_key_str_from_js)
        private_key = load_private_key(private_key_str_from_js)

        original_message = "你好, RSA encryption and decryption!"
        print(f"Original message: {original_message}")

        # Try different padding methods for encryption
        padding_methods = ['OAEP_SHA256', 'OAEP_SHA1', 'PKCS1v15']
        for padding_method in padding_methods:
            print(f"\nTesting with {padding_method} padding:")
            encrypted = encrypt_message(original_message, public_key, padding_method)
            print(f"Encrypted message: {encrypted}")

            try:
                decrypted, method_used = decrypt_message(encrypted, private_key)
                print(f"Decrypted message: {decrypted}")
                print(f"Decryption method used: {method_used}")
            except ValueError as e:
                print(f"Decryption failed: {str(e)}")

        # Test with the provided JavaScript encrypted message
        js_encrypted = "dzFAN3f3RTheLuvsaQQBB7wA/IQqgdEAGqQ2CQS5RSKgrNhI7O6/o+g4eeicXJUGpIUsVC1IwGVP4/bGqTvRjb/MfEtCVZGoMR+2yo8SIDPONi40SwvjnjTH1bdVQd53I+htoJrY7pvuQ0uz0UG3VUdXciNeU6eT45FB+p9zEAg="
        try:
            decrypted_js, method_used = decrypt_message(js_encrypted, private_key)
            print(f"\nDecrypted message from JavaScript: {decrypted_js}")
            print(f"Decryption method used for JS message: {method_used}")
        except ValueError as e:
            print(f"\nFailed to decrypt JavaScript message: {str(e)}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

    print("------------------------------------")
    # try:
    #     public_key = load_public_key(public_key_str_from_openssl)
    #     private_key = load_private_key(private_key_str_from_openssl, "")

    #     original_message = "你好, RSA encryption and decryption!"
    #     print(f"Original message: {original_message}")

    #     # Try different padding methods for encryption
    #     padding_methods = ['OAEP_SHA256', 'OAEP_SHA1', 'PKCS1v15']
    #     decrypt_message_0 = ""
    #     for padding_method in padding_methods:
    #         # print(f"\nTesting with {padding_method} padding:")
    #         encrypted = encrypt_message(original_message, public_key, padding_method)
    #         # print(f"Encrypted message: {encrypted}")

    #         try:
    #             decrypted, method_used = decrypt_message(encrypted, private_key)
    #             decrypt_message_0 = decrypted
    #             print(f"Decrypted message: {decrypted}")
    #             # print(f"Decryption method used: {method_used}")
    #         except ValueError as e:
    #             pass
    #             # print(f"Decryption failed: {str(e)}")
    #     # print(f"encrypted message: {decrypt_message_0}")

    # except Exception as e:
    #     pass
    #     # print(f"An error occurred: {str(e)}")