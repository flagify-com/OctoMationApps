# 变量生成器

- Version: 1.0.0
- author: wuzfukui
- udpated: Oct 29,2023

# 使用说明

当你希望在某个节点执行前，先做一些变量的准备，可以使用变量生成器帮你一次性准备好。例如，在HTTP Client请求前，通过变量生成器组织HTTP头参数以及签名结果，之后提交HTTP Client发起请求。

默认提供：
- 6个string及标签
- 3个int及标签
- 2个double及标签
- 1个boolean及标签